
public interface EventHandler {
	
	//some Text
	
	public void processEvent(Event e);

}
