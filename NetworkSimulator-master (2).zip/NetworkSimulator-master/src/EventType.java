
public enum EventType {
	
	SEND,
	RECEIVE;

}
